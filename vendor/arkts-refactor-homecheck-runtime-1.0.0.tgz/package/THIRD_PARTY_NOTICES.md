# Third-party notices

This package redistributes patched HomeCheck and ArkAnalyzer and compiled custom rules. Original copyright and license notices are retained alongside their files; patches are included in patches/.

- arkanalyzer@1.0.92: SEE LICENSE IN PACKAGE
- commander@13.1.0: MIT
- date-format@4.0.14: MIT
- debug@4.4.3: MIT
- flatted@3.4.2: ISC
- fs-extra@8.1.0: MIT
- graceful-fs@4.2.11: ISC
- homecheck@0.9.9-rc.26: ISC
- fs-extra@11.3.0: MIT
- jsonfile@6.2.0: MIT
- universalify@2.0.1: MIT
- universalify@2.0.1: MIT
- jsonfile@4.0.0: MIT
- log4js@6.9.1: Apache-2.0
- ms@2.1.3: MIT
- ohos-typescript@4.9.5-r4: Apache-2.0
- rfdc@1.4.1: MIT
- semver@7.7.2: ISC
- streamroller@3.1.5: MIT
- universalify@0.1.2: MIT
- ohos-typescript@4.9.5-r4: Apache-2.0 (bundled by ArkAnalyzer).
